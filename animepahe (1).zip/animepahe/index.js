// Example Animepahe index.js file
function search(query) {
    return [{ title: "Demo Anime", url: "https://animepahe.com/" }];
}
